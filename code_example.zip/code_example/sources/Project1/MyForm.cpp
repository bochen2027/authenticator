#include "MyForm.h"
#include <stdlib.h>
#include <time.h>
#include <string>
using namespace System;
//using namespace std;
using namespace System::Windows::Forms;

[STAThreadAttribute]

void Main(array<String^>^ args)
{
    Application::EnableVisualStyles(); Application::SetCompatibleTextRenderingDefault(false); Project1::MyForm form;
    


    Application::Run(% form);
}

